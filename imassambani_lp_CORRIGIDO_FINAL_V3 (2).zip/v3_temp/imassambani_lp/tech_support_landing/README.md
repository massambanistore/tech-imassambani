# 🔧 iMassambani Assistência Técnica - Landing Page

Landing page profissional para serviços de assistência técnica de celulares e notebooks, 100% conforme políticas do Google Ads.

## 📋 Informações da Landing Page

### ✅ Conformidade Google Ads
- ✓ Endereço físico: Ribeirão Preto - SP
- ✓ Telefone real: (16) 99390-8874
- ✓ WhatsApp: https://wa.me/5516993908874
- ✓ Horário de funcionamento completo
- ✓ Preços transparentes
- ✓ Política de privacidade
- ✓ Termos de uso
- ✓ Política de garantia (90 dias)

### 🎨 Identidade Visual
- **Nome:** iMassambani Assistência Técnica
- **Cor principal:** Azul-marinho (#1B3A6D)
- **Estilo:** Minimalista, tecnológico, clean e profissional
- **Tipografia:** Poppins (títulos) + Inter (corpo)

### 📱 Funcionalidades
- Tabs interativas (Celulares/Notebooks)
- Botões WhatsApp com mensagens pré-formatadas
- Scroll suave entre seções
- Animações de entrada
- 100% Responsivo
- SEO otimizado

### 💰 Serviços e Preços

#### Celulares:
- Troca de Tela: a partir de R$ 150,00
- Troca de Bateria: a partir de R$ 80,00
- Reparo de Placa: a partir de R$ 120,00
- Desoxidação: a partir de R$ 100,00

#### Notebooks:
- Formatação Completa: a partir de R$ 100,00
- Upgrade de Hardware: a partir de R$ 80,00 + peças
- Limpeza e Manutenção: a partir de R$ 80,00
- Reparo de Placa-Mãe: a partir de R$ 150,00

## 📂 Estrutura de Arquivos

```
tech_support_landing/
├── index.html      # Página principal
├── styles.css      # Estilos CSS
├── script.js       # Interatividade JavaScript
└── README.md       # Este arquivo
```

## 🔧 Como Editar

### Alterar Número de WhatsApp:
1. Abra `script.js`
2. Procure por `5516993908874`
3. Substitua pelo novo número (formato: 55 + DDD + número)

### Alterar Preços:
1. Abra `index.html`
2. Procure por `servico-preco`
3. Edite os valores conforme necessário

### Alterar Cores:
1. Abra `styles.css`
2. No início, procure por `:root`
3. Altere as variáveis de cor:
   - `--primary`: Cor principal
   - `--secondary`: Cor secundária (WhatsApp)
   - `--dark`: Cor escura
   - `--gray`: Cor cinza

### Adicionar/Remover Serviços:
1. Abra `index.html`
2. Procure por `servico-card`
3. Copie um card existente e edite o conteúdo

## 🌐 URL Planejada

**Subdomínio:** `assistencia.imassambani.com.br`

**Hospedagem:** Netlify (grátis)

**Domínio principal:** `imassambani.com.br` (Loja Integrada)

## 📞 Informações de Contato

- **WhatsApp:** (16) 99390-8874
- **Telefone:** (16) 99390-8874
- **Email:** contato@imassambani.com.br
- **Horário:** Seg-Sex 9h-18h, Sáb 9h-13h
- **Localização:** Ribeirão Preto - SP

## 🚀 Deploy

Siga o arquivo `GUIA_CONFIGURACAO_SUBDOMINIO.md` para instruções completas de como colocar o site no ar.

## ✅ Checklist Pré-Lançamento

- [ ] Testar todos os botões de WhatsApp
- [ ] Verificar se os preços estão corretos
- [ ] Testar responsividade (mobile, tablet, desktop)
- [ ] Verificar ortografia e gramática
- [ ] Testar navegação entre seções
- [ ] Confirmar informações de contato
- [ ] Verificar se HTTPS está ativo
- [ ] Testar velocidade de carregamento

## 📊 Métricas para Acompanhar

Após lançar no Google Ads, monitore:
- Taxa de cliques (CTR)
- Taxa de conversão
- Tempo médio na página
- Taxa de rejeição
- Cliques nos botões de WhatsApp
- Origem do tráfego

## 🎯 Dicas para Google Ads

1. Use palavras-chave específicas: "assistência técnica celular ribeirão preto"
2. Crie anúncios diferentes para celulares e notebooks
3. Teste diferentes títulos e descrições
4. Configure conversões (cliques no WhatsApp)
5. Ajuste lances por horário (9h-18h)
6. Foque em raio de 20km de Ribeirão Preto

## 📝 Notas Importantes

- Todos os preços são "a partir de" para transparência
- Garantia de 90 dias em todos os serviços
- Orçamento gratuito destacado
- Políticas de privacidade e termos incluídos
- Design otimizado para conversão

---

**Desenvolvido para iMassambani Assistência Técnica**
**Data:** 2024
**Versão:** 1.0
