// Funções de navegação e contato

function scrollToServicos() {
    const servicos = document.getElementById('servicos');
    servicos.scrollIntoView({ behavior: 'smooth' });
}

// Função para alternar entre tabs de serviços
function showTab(tabName) {
    // Esconder todas as tabs
    const tabContents = document.querySelectorAll('.tab-content');
    tabContents.forEach(tab => {
        tab.classList.remove('active');
    });

    // Remover active de todos os botões
    const tabBtns = document.querySelectorAll('.tab-btn');
    tabBtns.forEach(btn => {
        btn.classList.remove('active');
    });

    // Mostrar tab selecionada
    const selectedTab = document.getElementById(tabName);
    if (selectedTab) {
        selectedTab.classList.add('active');
    }

    // Adicionar active ao botão clicado
    const clickedBtn = event.target;
    clickedBtn.classList.add('active');
}

// Smooth scroll para links de navegação
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        const href = this.getAttribute('href');
        
        // Ignorar links que são apenas # ou começam com #politica
        if (href === '#' || href.startsWith('#politica')) {
            return;
        }
        
        e.preventDefault();
        const target = document.querySelector(href);
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Animação de entrada dos elementos quando visíveis
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Aplicar animação aos cards
document.addEventListener('DOMContentLoaded', function() {
    const animatedElements = document.querySelectorAll('.diferencial-card, .servico-card, .contato-card');
    
    animatedElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
});

// Highlight do link ativo na navegação
window.addEventListener('scroll', function() {
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav a[href^="#"]');
    
    let current = '';
    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;
        if (pageYOffset >= (sectionTop - 200)) {
            current = section.getAttribute('id');
        }
    });
    
    navLinks.forEach(link => {
        link.style.fontWeight = '500';
        link.style.color = 'var(--gray)';
        
        const href = link.getAttribute('href');
        if (href === `#${current}`) {
            link.style.fontWeight = '700';
            link.style.color = 'var(--primary)';
        }
    });
});

// Tracking de cliques em botões de WhatsApp (para analytics)
document.querySelectorAll('a[href*="wa.me"]').forEach(link => {
    link.addEventListener('click', function() {
        console.log('WhatsApp clicked:', this.href);
        // Aqui você pode adicionar código de tracking (Google Analytics, Facebook Pixel, etc)
    });
});

// Tracking de cliques em botões de telefone
document.querySelectorAll('a[href^="tel:"]').forEach(link => {
    link.addEventListener('click', function() {
        console.log('Phone clicked:', this.href);
        // Aqui você pode adicionar código de tracking
    });
});

// Menu mobile (para responsividade futura)
function toggleMobileMenu() {
    const nav = document.querySelector('.nav');
    nav.classList.toggle('mobile-active');
}

// Log de carregamento
console.log('iMassambani Assistência Técnica - Landing Page carregada com sucesso!');
console.log('WhatsApp: https://wa.me/5516993908874');
console.log('Telefone: (16) 99390-8874');
